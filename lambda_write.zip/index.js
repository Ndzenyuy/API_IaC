const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();
const tableName = process.env.TABLE_NAME;

exports.handler = async (event) => {
    const requestBody = JSON.parse(event.body);
    const params = {
        TableName: tableName,
        Item: {
            id: "1",
            resume: requestBody.resume,
            // Add more attributes as needed
        },
    };

    try {
        await dynamoDb.put(params).promise();
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Data written successfully' }),
        };
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Error writing data', error }),
        };
    }
};
